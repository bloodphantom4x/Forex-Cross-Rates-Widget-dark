# Forex Cross Rates Widget

A Pen created on CodePen.io. Original URL: [https://codepen.io/Gab-Blood/pen/vEBExwj](https://codepen.io/Gab-Blood/pen/vEBExwj).

